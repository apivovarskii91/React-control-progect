import { Typography } from '@mui/material'
import Button from '@mui/material/Button'

type Props = {}
const ButtonGroup = (props: Props) => {
    return (
        <>
            <Typography align="center" className="btn">
                <Button>change count()</Button>
                <Button>change count()</Button>
                <Button>change count()</Button>
            </Typography>
        </>
    )
}
export default ButtonGroup
