import { Container } from '@mui/material'
import ButtonGroup from 'components/ButtonGroup/ButtonGroup'

type Props = {}
const Main = (props: Props) => {
    return (
        <>
            <Container component="main" sx={{ padding: '60px 0' }}>
                <ButtonGroup />
            </Container>
        </>
    )
}
export default Main
