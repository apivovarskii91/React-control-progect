type Props = {}
const Header = (props: Props) => {
    return <div>Header</div>
}
export default Header
